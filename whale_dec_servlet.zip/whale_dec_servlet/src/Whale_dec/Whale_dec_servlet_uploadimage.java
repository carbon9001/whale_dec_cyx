package Whale_dec;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/Whale_dec_servlet_uploadimage")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 1, // 1 MB
maxFileSize = 1024 * 1024 * 5, // 5 MB
maxRequestSize = 1024 * 1024 * 10)// 10 MB

public class Whale_dec_servlet_uploadimage extends HttpServlet {

	 private static final long serialVersionUID = 1L;

	 protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		 boolean head = false;
	//first we need to get the email name, user name, and the image itself
		 String email = (String) request.getParameter("email");
		 String x1 = (String) request.getParameter("x1");
		 String y1 = (String) request.getParameter("y1");
		 String err = new String();
		 if(x1.equals(new String(""))||y1.equals(new String(""))){
			 head = false;
		 }else{
			 head = true;
		 }
		 //get file name and extension
		 Part part = request.getPart("file");
		 String fileName = getFileName(part);	
		 //String[] fileName2 = fileName.split("\\\\");
		 String[] fileName2 = fileName.split("\\\\/");
		 fileName = fileName2[fileName2.length-1];
		 
		 //String[] ext = fileName.split(".");
		 //System.out.print(ext.length);
		 //String ext_image = ext[ext.length-1];
		 String ext_image = fileName.substring(fileName.lastIndexOf(".")+1);
		 String imageDir = getServletContext().getRealPath(File.separator+"upload"); 
		 String fileDir=new String();
		 //rename the file
		 if(email==null || email.equals(new String(""))){
			 SessionInfo info = new SessionInfo();
			 String ip=info.getRemoteAddress(request);
			 ip = stringFilter(ip);
			 fileDir = imageDir+File.separator+ip+"."+ext_image;		 
		 }else{
			 fileDir = imageDir+File.separator+email+"."+ext_image;
		 }
		 //********************************************************
		 //this part is for demo on class only!
		 //please delete it after it works!
		 
		 fileName="whale_image";
		 //imageDir = "C:\\Users\\Yingxi\\Desktop";
		 imageDir = "/home/adarsh/Documents/temp_whale";
		 fileDir = imageDir+File.separator+fileName+"."+ext_image;
		 
		 //the cod above is for demon only!
		 //*********************************************************8
		 part.write(fileDir);
		 //put the files info into image diatabase
		 TestDB_Image imdb = new TestDB_Image();
		 ServletContext context = this.getServletConfig().getServletContext();
		 context.setAttribute("image_db", imdb);  
		 if(email==null || email.equals(new String(""))){
			 imdb.addImageInfo(request, fileDir);
		 }else{
			 imdb.addImageInfo(email,fileDir);
		 }
		 
		 //Get Image object
		 File tempImage = new File(fileDir);
		 BufferedImage image = ImageIO.read(tempImage);
		 if(head){
			 Integer x=Integer.valueOf(x1);
			 Integer y=Integer.valueOf(y1);
			 if(x!=0 && y!=0){
				 int h=image.getHeight();
				 int w=image.getWidth();
				 if((x+256<=w)&&(y+256)<=h){
					 image=image.getSubimage(x , y, 256, 256);
					 //fileDir = imageDir+File.separator+"abc."+ext_image;
					 File outputfile = new File(fileDir);
					 ImageIO.write(image, ext_image, outputfile);
					 head = true;
				 }
			 }
		 }
		 String shell_path = imageDir + File.separator+"test.sh";
		 if(head){
			 //call only random forest script		 
			 try {
				 ///home/adarsh/Documents/temp_whale/test.sh
				 
				  Process ps = Runtime.getRuntime().exec(shell_path);
				  ps.waitFor();
				  err = "shell called";
				  
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				err = err+e.getMessage();
			}
		 }else{
			 //call other script	 
			 try {
				Process ps = Runtime.getRuntime().exec(shell_path);
				ps.waitFor();
				err = "shell called";
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				err =err+e.getMessage();
			}
		 }
		 try {
			Thread.sleep(7000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		 //read from txt file
		 String line = "";
		 try { 
				/* ����TXT�ļ� */
				String pathname = imageDir +File.separator+"whale_image.txt"; // ����·�������·�������ԣ������Ǿ���·����д���ļ�ʱ��ʾ���·��
			    //String pathname = "/home/adarsh/Documents/temp_whale/whale_image.txt";
				File filename = new File(pathname); // Ҫ��ȡ����·����input��txt�ļ�
				InputStreamReader reader = new InputStreamReader(
						new FileInputStream(filename)); // ����һ������������reader
				BufferedReader br = new BufferedReader(reader); // ����һ�����������ļ�����ת�ɼ�����ܶ���������				
				line = br.readLine();
				String[] result = line.split("@");
				String iswhale=result[0];
				String whaleid = result[1];
			} catch (Exception e) {
				e.printStackTrace();
			}
		 
		 //response
		 response.setHeader("Access-Control-Allow-Origin", "*");
		 response.getWriter().print(line+"@"+fileName + " uploaded successfully"+err);
		 
/*		 
	  Part part = request.getPart("blob");
	  String fileName = null;
	  if (part != null) {
	   //writing blob
	   fileName = request.getParameter("blobName");
	   part.write("path/to/upload" + File.separator + fileName);

	  } else {
	   //Writing image or file
	   part = request.getPart("file");
	   fileName = getFileName(part);
	   part.write("path/to/upload" + File.separator + fileName);
	  }

	  // Extra logic to support multiple domain - you may want to remove this
	  response.setHeader("Access-Control-Allow-Origin", "*");
	  response.getWriter().print(fileName + " uploaded successfully");
	 }
*/
}
	 private String getFileName(Part part) {
	  String contentDisp = part.getHeader("content-disposition");
	  System.out.println("content-disposition header= " + contentDisp);
	  String[] tokens = contentDisp.split(";");
	  for (String token : tokens) {
	   if (token.trim().startsWith("filename")) {
	    return token.substring(token.indexOf("=") + 2,
	      token.length() - 1);
	   }
	  }
	  return "";
	 }
	 
	 private String stringFilter(String str){
		 {     
			          
			String regEx="[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~��@#��%����&*��������+|{}������������������������]";  
			Pattern   p   =   Pattern.compile(regEx);     
			Matcher   m   =   p.matcher(str);     
			return   m.replaceAll("").trim();     
		 } 

	 }
}


	
