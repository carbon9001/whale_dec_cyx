package Whale_dec;

import java.awt.Image;

public class ImageProcessor {
	public boolean checkImageSize(Image image){
		return true;
	}
	public boolean checkImageType(Image image){
		return true;
	}
	public boolean renameImage(Image image, String newname){
		return true;
	}
	
	public boolean saveImage(Image image, String path){
		return true;
	}
	
	public Image zipImage(Image image){
		return image;
	}
	
}
