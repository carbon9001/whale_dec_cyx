package Whale_dec;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;

public class TestDB_Image {
	public static Hashtable<String,String> image_table = new Hashtable<String,String>();
	
	public String addImageInfo(String uploader, String uploaddir) {
			String path = image_table.get(uploader);//Retrieve a record using id as key
											//see if the record exists in the hash table
			if(path==null){					//the record does not exists in hash table
				image_table.put(uploader, uploaddir);//add the record to the hash table
				return "new";					//tell the web page added record sucessfully
			}else{
				image_table.put(uploader, uploaddir);
				return "replaced";					//tell the web page the record already exists
			}
	}
	
	public String getImageByUploader(String uploader){
		String path = image_table.get(uploader);
		if(path!=null){
			return path;
		}else{
			return "";
		}
	}
	
	public  String addImageInfo(HttpServletRequest request,String uploaddir){
		SessionInfo info = new SessionInfo();
		String ip=info.getRemoteAddress(request);
		String path = image_table.get(ip);//Retrieve a record using id as key
		//see if the record exists in the hash table
		if(path==null){					//the record does not exists in hash table			
			image_table.put(ip, uploaddir);//add the record to the hash table
			return "new";					//tell the web page added record sucessfully
		}else{
			image_table.put(ip, uploaddir);
			return "replaced";					//tell the web page the record already exists
		}
	}

}
